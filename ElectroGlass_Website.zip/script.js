
const slider=document.getElementById('tintSlider');
const glass=document.getElementById('glassPane');

if(slider){
slider.addEventListener('input',()=>{
 const v=slider.value;
 glass.style.background=`rgba(20,40,70,${v/100})`;
});
}

const observer=new IntersectionObserver(entries=>{
 entries.forEach(e=>{
   if(e.isIntersecting){e.target.classList.add('active')}
 });
});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
